import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { CommonHeader } from './components/layout/CommonHeader';
import { Footer } from './components/layout/Footer';
import { LandingPage } from './components/landing/LandingPage';
import { AboutPage } from './components/landing/AboutPage';
import { FaqPage } from './components/landing/FaqPage';
import { ContactPage } from './components/landing/ContactPage';
import { InstitutionDashboard } from './components/institution/InstitutionDashboard';
import { ProjectDetailView } from './components/institution/ProjectDetailView';
import { TeamCreationModal } from './components/institution/TeamCreationModal';
import { ProjectWorkspace } from './components/institution/ProjectWorkspace';
import { MentorDashboard } from './components/mentor/MentorDashboard';
import { CollectorDashboard } from './components/collector/CollectorDashboard';
import { SuperAdminDashboard } from './components/admin/SuperAdminDashboard';
import { CertificateView } from './components/certificates/CertificateView';
import { InstitutionRegisterModal } from './components/auth/InstitutionRegisterModal';
import { MentorRegisterModal } from './components/auth/MentorRegisterModal';
import { LoginModal } from './components/auth/LoginModal';
import { NotificationDrawer } from './components/notifications/NotificationDrawer';
import { ErrorBanner } from './components/common/ErrorBanner';
import { UserRole } from './types';

const AppContent: React.FC = () => {
  const { 
    currentUser, 
    activePage, 
    setActivePage, 
    selectedProjectId, 
    setSelectedProjectId
  } = useApp();

  // Modals visibility
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginInitialRole, setLoginInitialRole] = useState<UserRole>('institution');
  const [instRegisterOpen, setInstRegisterOpen] = useState(false);
  const [mentorRegisterOpen, setMentorRegisterOpen] = useState(false);
  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [teamModalProjectId, setTeamModalProjectId] = useState<string>('');
  
  // Notification Drawer
  const [notifDrawerOpen, setNotifDrawerOpen] = useState(false);
  const [notifDrawerMode, setNotifDrawerMode] = useState<'in-portal' | 'emails'>('in-portal');

  // Certificate project ID
  const [certProjectId, setCertProjectId] = useState<string>('PRJ-DST-003');

  // Always scroll to the top of the page when navigating between views
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    document.documentElement.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    document.body.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [activePage, selectedProjectId]);

  // Route student automatically to their assigned project workspace
  useEffect(() => {
    if (currentUser?.role === 'student' && currentUser.projectId) {
      setSelectedProjectId(currentUser.projectId);
      if (activePage === 'dashboard' || activePage === 'home') {
        setActivePage('workspace');
      }
    }
  }, [currentUser]);

  const handleOpenLogin = (role?: UserRole) => {
    setLoginInitialRole(role || 'institution');
    setLoginModalOpen(true);
  };

  const handleSelectProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setActivePage('project-detail');
  };

  const handleBlockAndCreateTeam = (projectId: string) => {
    setTeamModalProjectId(projectId);
    setTeamModalOpen(true);
  };

  const handleOpenWorkspace = (projectId: string) => {
    setSelectedProjectId(projectId);
    setActivePage('workspace');
  };

  const handleOpenCertificates = (projectId: string) => {
    setCertProjectId(projectId);
    setActivePage('certificates');
  };

  return (
    <div className="min-h-screen flex flex-col text-slate-800 antialiased">
      
      {/* 1. Official Header with both Tamil Nadu Emblem & Triple Helix Brand Logos */}
      <CommonHeader 
        onOpenNotifications={() => {
          setNotifDrawerMode('in-portal');
          setNotifDrawerOpen(true);
        }}
        onOpenLogin={handleOpenLogin}
        onOpenRegisterInstitution={() => setInstRegisterOpen(true)}
        onOpenRegisterMentor={() => setMentorRegisterOpen(true)}
      />

      {/* 2. Dynamic View Router */}
      <div className="flex-1 flex flex-col">
        {activePage === 'home' && (
          <LandingPage
            onOpenLogin={handleOpenLogin}
            onOpenRegisterInstitution={() => setInstRegisterOpen(true)}
            onOpenRegisterMentor={() => setMentorRegisterOpen(true)}
          />
        )}

        {activePage === 'about' && <AboutPage />}

        {activePage === 'faq' && <FaqPage />}

        {activePage === 'contact' && <ContactPage />}

        {activePage === 'dashboard' && (
          <>
            {currentUser?.role === 'institution' && (
              <InstitutionDashboard
                onSelectProject={handleSelectProject}
                onOpenWorkspace={handleOpenWorkspace}
              />
            )}
            {currentUser?.role === 'student' && selectedProjectId && (
              <ProjectWorkspace
                projectId={selectedProjectId}
                onBackToDashboard={() => setActivePage('home')}
                onOpenCertificates={handleOpenCertificates}
              />
            )}
            {currentUser?.role === 'mentor' && <MentorDashboard />}
            {currentUser?.role === 'collector' && (
              <CollectorDashboard onOpenCertificates={handleOpenCertificates} />
            )}
            {currentUser?.role === 'superadmin' && (
              <SuperAdminDashboard onOpenCertificates={handleOpenCertificates} />
            )}
            {!currentUser && (
              <LandingPage
                onOpenLogin={handleOpenLogin}
                onOpenRegisterInstitution={() => setInstRegisterOpen(true)}
                onOpenRegisterMentor={() => setMentorRegisterOpen(true)}
              />
            )}
          </>
        )}

        {activePage === 'project-detail' && selectedProjectId && (
          <ProjectDetailView
            projectId={selectedProjectId}
            onBack={() => setActivePage(currentUser ? 'dashboard' : 'home')}
            onBlockAndCreateTeam={() => handleBlockAndCreateTeam(selectedProjectId)}
            onOpenWorkspace={() => handleOpenWorkspace(selectedProjectId)}
          />
        )}

        {activePage === 'workspace' && selectedProjectId && (
          <ProjectWorkspace
            projectId={selectedProjectId}
            onBackToDashboard={() => setActivePage(currentUser?.role === 'student' ? 'home' : 'dashboard')}
            onOpenCertificates={handleOpenCertificates}
          />
        )}

        {activePage === 'certificates' && certProjectId && (
          <CertificateView
            projectId={certProjectId}
            onBack={() => setActivePage(currentUser?.role === 'student' ? 'workspace' : (currentUser ? 'dashboard' : 'home'))}
          />
        )}
      </div>

      {/* 3. Footer with Official Logos and Government Contact Details */}
      <Footer />

      {/* Modals & Drawers */}
      <InstitutionRegisterModal
        isOpen={instRegisterOpen}
        onClose={() => setInstRegisterOpen(false)}
        onSuccessLoginPrompt={() => handleOpenLogin('institution')}
      />

      <MentorRegisterModal
        isOpen={mentorRegisterOpen}
        onClose={() => setMentorRegisterOpen(false)}
        onSuccessLoginPrompt={() => handleOpenLogin('mentor')}
      />

      <LoginModal
        isOpen={loginModalOpen}
        initialRole={loginInitialRole}
        onClose={() => setLoginModalOpen(false)}
        onSwitchToRegister={(role) => {
          if (role === 'institution') setInstRegisterOpen(true);
          else if (role === 'mentor') setMentorRegisterOpen(true);
        }}
      />

      {teamModalOpen && teamModalProjectId && (
        <TeamCreationModal
          isOpen={teamModalOpen}
          projectId={teamModalProjectId}
          onClose={() => setTeamModalOpen(false)}
          onTeamCreatedSuccess={() => {
            setSelectedProjectId(teamModalProjectId);
            setActivePage('workspace');
          }}
        />
      )}

      <NotificationDrawer
        isOpen={notifDrawerOpen}
        onClose={() => setNotifDrawerOpen(false)}
        initialMode={notifDrawerMode}
        onSelectProject={(pId) => {
          setSelectedProjectId(pId);
          setActivePage('workspace');
        }}
      />

      {/* Error Handler Banner */}
      <ErrorBanner />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
