import { HeroSlide } from '../types';

export const HERO_IMAGE_PRESETS = [
  {
    name: 'Smart Urban Logistics & Edge AI',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=80',
    caption: 'Edge Microcontroller & Telemetry Prototyping'
  },
  {
    name: 'Student Engineering Laboratory',
    url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80',
    caption: 'PSG Tech & Anna University Hardware Labs'
  },
  {
    name: 'Clean Solar & Renewable Telemetry',
    url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=1000&q=80',
    caption: 'Tribal Solar Microgrid & Remote Sensing'
  },
  {
    name: 'Smart Water & Irrigation Robotics',
    url: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1000&q=80',
    caption: 'Canal Flow Monitoring & Automated Sluice'
  },
  {
    name: 'Public Healthcare Diagnostic Cold-Chain',
    url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1000&q=80',
    caption: 'District Vaccine Thermal Telemetry Sensor'
  },
  {
    name: 'Autonomous Drone & Civic Road Vision',
    url: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=1000&q=80',
    caption: 'Autonomous Aerial Survey & Infrastructure Audit'
  }
];

export const DEFAULT_HERO_SLIDES: HeroSlide[] = [
  {
    id: 'slide-01',
    badge: 'Coimbatore District Innovation Mission',
    headlineMain: 'Your Engineering Innovation Is Just',
    headlineHighlight: 'A Milestone Away',
    description: 'Connecting accredited engineering colleges and industry leaders with verified District Administration problem statements across Coimbatore District. Solve real civic challenges through verified milestone gates.',
    primaryCtaText: 'Explore Problem Statements',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'Learn About the Tripartite Model',
    secondaryCtaAction: 'about',
    theme: 'amber',
    category: 'District Innovation',
    active: true,
    departmentTag: 'District Collectorate IT & e-Governance Cell',
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Collegiate engineering students and mentors collaborating on civic innovation prototype',
    imageCaption: 'PSG Tech & GCT Innovation Labs · Hardware Engineering Lab'
  },
  {
    id: 'slide-02',
    badge: 'Municipal Administration & Smart City Mission',
    headlineMain: 'Transforming Urban Utilities Through',
    headlineHighlight: 'IoT & Edge Telemetry',
    description: 'Direct municipal collaboration with college engineering laboratories: dynamic bin telemetry, compactor fleet routing optimization, and automated waste segregation verification.',
    primaryCtaText: 'View Waste & Transit Challenges',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'Learn More',
    secondaryCtaAction: 'about',
    theme: 'emerald',
    category: 'Urban Governance',
    active: true,
    departmentTag: 'Municipal Administration Department',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Smart city telemetry sensor hardware and edge compute board',
    imageCaption: '124+ Smart City Sensor Nodes · Municipal IoT Network'
  },
  {
    id: 'slide-03',
    badge: 'Higher Education & Corporate Mentorship Council',
    headlineMain: 'Empowering Student Engineering Teams With',
    headlineHighlight: 'Top Industry Mentors',
    description: 'Leading corporate architects guide student teams through design reviews, hardware-in-the-loop testing, and government-certified completions.',
    primaryCtaText: 'Join as Industry Mentor',
    primaryCtaAction: 'register-mentor',
    secondaryCtaText: 'Explore Mentors',
    secondaryCtaAction: 'about',
    theme: 'sky',
    category: 'Industry Guidance',
    active: true,
    departmentTag: 'Technical Advisory Council',
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Corporate industry mentor conducting technical design review with collegiate team',
    imageCaption: '1:1 Corporate Architect Mentorship · Industry Guidance'
  },
  {
    id: 'slide-04',
    badge: 'Agriculture & Rural Healthcare Transformation',
    headlineMain: 'From College Laboratory Prototypes to',
    headlineHighlight: 'District-Wide Deployment',
    description: 'Motorized canal sluice gates and solar-buffered vaccine cold chain loggers currently serving rural blocks across Anaimalai, Valparai, and Pollachi.',
    primaryCtaText: 'Browse Agritech & Health Projects',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'View Project Details',
    secondaryCtaAction: 'about',
    theme: 'indigo',
    category: 'Rural Development',
    active: true,
    departmentTag: 'District Rural Development Agency',
    imageUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Solar powered microgrid and remote monitoring station deployed in rural block',
    imageCaption: '18 Rural Blocks Active · DRDA Rural Initiatives'
  }
];

export const AI_HERO_TEMPLATES: Omit<HeroSlide, 'id'>[] = [
  {
    badge: 'Municipal Clean Energy Initiative',
    headlineMain: 'Autonomous Urban Logistics &',
    headlineHighlight: 'Clean Energy Telemetry',
    description: 'Harnessing LoRaWAN mesh and edge vision models to modernize municipal compactor dispatch and off-grid tribal solar microgrids.',
    primaryCtaText: 'Explore Clean Energy Projects',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'About Initiative',
    secondaryCtaAction: 'about',
    theme: 'emerald',
    category: 'Smart Cities',
    active: true,
    departmentTag: 'Smart Cities Mission',
    imageUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Solar microgrid installation',
    imageCaption: 'Smart Grid & Edge Vision'
  },
  {
    badge: 'Agritech Irrigation Council',
    headlineMain: 'Equitable Canal Water Sharing Through',
    headlineHighlight: 'Automated Sluice Robotics',
    description: 'Sub-GHz radio telemetry and solar planetary actuator valves delivering precise volumetric irrigation to tail-end cotton farmers.',
    primaryCtaText: 'View Water Resources Projects',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'Learn More',
    secondaryCtaAction: 'about',
    theme: 'amber',
    category: 'Irrigation & Water',
    active: true,
    departmentTag: 'Public Works & Water Resources',
    imageUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Canal water irrigation robotics',
    imageCaption: 'Automated Sluice Telemetry'
  },
  {
    badge: 'Public Healthcare Logistics Mission',
    headlineMain: 'Zero-Fail Cold Chain Guardian For',
    headlineHighlight: 'Primary Health Center Vaccines',
    description: 'Cryptographically signed sub-zero thermal telemetry and automated GSM Medical Officer voice escalations for remote clinics.',
    primaryCtaText: 'Explore Public Health Projects',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'About Public Health',
    secondaryCtaAction: 'about',
    theme: 'sky',
    category: 'Healthcare',
    active: true,
    departmentTag: 'Department of Public Health',
    imageUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Medical cold chain storage',
    imageCaption: 'Vaccine Cold-Chain Guardian'
  }
];
