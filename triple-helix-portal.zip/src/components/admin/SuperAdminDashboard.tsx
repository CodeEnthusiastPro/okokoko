import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Project, TechnologyCategory, Milestone } from '../../types';
import { CollectorDashboard } from '../collector/CollectorDashboard';
import { HeroSlideshowManager } from './HeroSlideshowManager';
import { FaqContactManager } from './FaqContactManager';
import { 
  ShieldCheck, 
  Plus, 
  Edit3, 
  Archive, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  Building2, 
  Users, 
  FileText, 
  History, 
  Layers, 
  Clock, 
  Upload, 
  MessageSquare, 
  Send,
  AlertCircle,
  Eye,
  X,
  Sparkles,
  HelpCircle
} from 'lucide-react';

interface Props {
  onOpenCertificates: (projectId: string) => void;
}

export const SuperAdminDashboard: React.FC<Props> = ({ onOpenCertificates }) => {
  const { 
    projects, 
    institutions, 
    mentors, 
    auditLogs, 
    heroSlides,
    createProject, 
    editProject, 
    archiveProject, 
    deleteProject, 
    reviewMilestoneAction, 
    assignMentorToProject,
    triggerError 
  } = useApp();

  // Navigation tab inside Admin Dashboard
  const [adminTab, setAdminTab] = useState<'analytics' | 'projects' | 'reviews' | 'institutions' | 'mentors' | 'slides' | 'faq-contact' | 'audit'>('reviews');

  // Milestone Review Modal State (SRS Section 15 & 16)
  const [reviewModalData, setReviewModalData] = useState<{
    project: Project;
    milestone: Milestone;
  } | null>(null);
  const [reviewAction, setReviewAction] = useState<'Approved' | 'Rejected'>('Approved');
  const [rejectionReason, setRejectionReason] = useState('');
  const [reviewComments, setReviewComments] = useState('');

  // Project Create/Edit Modal State (SRS Section 21 & 22)
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [projectForm, setProjectForm] = useState({
    id: '',
    title: '',
    department: 'Municipal Administration',
    sector: 'Urban Governance',
    duration: '4 Months',
    technologyCategory: 'Software' as TechnologyCategory,
    description: '',
    objectivesText: '',
    deliverablesText: '',
    skillsText: '',
    refDocTitle: '',
    attachmentName: ''
  });

  // Assign Mentor Modal State
  const [assignModalProject, setAssignModalProject] = useState<Project | null>(null);
  const [selectedMentorId, setSelectedMentorId] = useState('');

  // Pending Reviews Count
  const pendingSubmissions = projects.flatMap(p => 
    p.milestones.filter(m => m.status === 'Submitted').map(m => ({ project: p, milestone: m }))
  );

  const handleOpenCreateProject = () => {
    setEditingProjectId(null);
    const newId = `PRJ-DST-00${projects.length + 1}`;
    setProjectForm({
      id: newId,
      title: '',
      department: 'Municipal Administration',
      sector: 'Urban Governance',
      duration: '4 Months',
      technologyCategory: 'Software',
      description: '',
      objectivesText: 'Design and deploy scalable pilot\nAchieve 20% operational efficiency\nDeploy open API for department integration',
      deliverablesText: 'Working prototype\nComprehensive documentation\nDeployment guidelines',
      skillsText: 'React, Node.js, Python, PostgreSQL',
      refDocTitle: 'Department Operational Standard 2026.pdf',
      attachmentName: 'Baseline_Department_Dataset.csv'
    });
    setIsProjectModalOpen(true);
  };

  const handleOpenEditProject = (p: Project) => {
    setEditingProjectId(p.id);
    setProjectForm({
      id: p.id,
      title: p.title,
      department: p.department,
      sector: p.sector,
      duration: p.duration,
      technologyCategory: p.technologyCategory,
      description: p.description,
      objectivesText: p.objectives.join('\n'),
      deliverablesText: p.expectedDeliverables.join('\n'),
      skillsText: p.requiredSkills.join(', '),
      refDocTitle: p.referenceDocuments[0]?.title || '',
      attachmentName: p.attachments[0]?.name || ''
    });
    setIsProjectModalOpen(true);
  };

  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();

    if (!projectForm.title.trim() || !projectForm.description.trim()) {
      triggerError('Project Selection Errors', 'Project Title and Description are required.');
      return;
    }

    const objectives = projectForm.objectivesText.split('\n').filter(s => s.trim().length > 0);
    const deliverables = projectForm.deliverablesText.split('\n').filter(s => s.trim().length > 0);
    const skills = projectForm.skillsText.split(',').map(s => s.trim()).filter(s => s.length > 0);

    if (editingProjectId) {
      editProject(editingProjectId, {
        title: projectForm.title,
        department: projectForm.department,
        sector: projectForm.sector,
        duration: projectForm.duration,
        technologyCategory: projectForm.technologyCategory,
        description: projectForm.description,
        objectives,
        expectedDeliverables: deliverables,
        requiredSkills: skills
      });
    } else {
      createProject({
        id: projectForm.id,
        title: projectForm.title,
        department: projectForm.department,
        sector: projectForm.sector,
        duration: projectForm.duration,
        technologyCategory: projectForm.technologyCategory,
        description: projectForm.description,
        objectives,
        expectedDeliverables: deliverables,
        requiredSkills: skills,
        referenceDocuments: [
          { title: projectForm.refDocTitle || 'Departmental Specifications.pdf', type: 'PDF', url: '#', size: '2.5 MB' }
        ],
        attachments: [
          { name: projectForm.attachmentName || 'Field_Survey_Data.csv', size: '1.2 MB', type: 'CSV' }
        ]
      });
    }

    setIsProjectModalOpen(false);
  };

  const handleProcessReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalData) return;

    if (reviewAction === 'Rejected') {
      if (!rejectionReason.trim() || !reviewComments.trim()) {
        triggerError('File Upload Errors', 'Both Rejection Reason and Review Comments are required when rejecting a milestone (SRS Section 15).');
        return;
      }
    }

    reviewMilestoneAction(
      reviewModalData.project.id,
      reviewModalData.milestone.id,
      reviewAction,
      rejectionReason,
      reviewComments
    );

    setReviewModalData(null);
    setRejectionReason('');
    setReviewComments('');
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Super Admin Top Control Center Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-purple-900/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-purple-300 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Full Administrative Control (SRS Section 21 & 22)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold">
              Super Admin Control Console
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Project curation, milestone review approvals, mentor pairing, institutional verification, and audit trace records.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleOpenCreateProject}
              className="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>+ Create Problem Statement</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 text-xs sm:text-sm font-semibold overflow-x-auto pb-1">
        
        <button
          onClick={() => setAdminTab('reviews')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors relative whitespace-nowrap ${
            adminTab === 'reviews'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Milestone Reviews</span>
          {pendingSubmissions.length > 0 && (
            <span className="bg-amber-400 text-slate-900 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {pendingSubmissions.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminTab('projects')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'projects'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Project Management ({projects.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('analytics')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'analytics'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Collector Analytics View</span>
        </button>

        <button
          onClick={() => setAdminTab('institutions')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'institutions'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Institutions ({institutions.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('mentors')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'mentors'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Mentors & Pairing ({mentors.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('slides')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'slides'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-purple-300" />
          <span>Hero Slides & Pictures ({heroSlides.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('faq-contact')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'faq-contact'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <HelpCircle className="w-4 h-4 text-sky-400" />
          <span>FAQ & Contact Manager</span>
        </button>

        <button
          onClick={() => setAdminTab('audit')}
          className={`py-2 px-4 rounded-lg flex items-center gap-2 transition-colors whitespace-nowrap ${
            adminTab === 'audit'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Audit Logs ({auditLogs.length})</span>
        </button>

      </div>

      {/* TAB 1: MILESTONE REVIEWS (SRS Section 15 & 16) */}
      {adminTab === 'reviews' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Submissions Requiring Review ({pendingSubmissions.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Under SRS Section 15, only Super Admin can approve or reject milestone submissions.
                </p>
              </div>
            </div>

            {pendingSubmissions.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 mb-2" />
                <p className="text-sm font-semibold text-slate-800">All submissions are up to date!</p>
                <p className="text-xs text-slate-500 mt-1">No pending student milestone submissions currently awaiting review.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingSubmissions.map(({ project, milestone }) => (
                  <div key={`${project.id}-${milestone.id}`} className="p-4 rounded-xl border border-sky-200 bg-sky-50/30 space-y-3 text-xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-100 pb-2">
                      <div>
                        <span className="font-mono font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded">
                          {project.id}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm mt-1">
                          {project.title}
                        </h3>
                        <p className="text-slate-600">
                          Institution: <strong>{project.selectedByInstitutionName}</strong>
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="bg-sky-600 text-white font-semibold px-2.5 py-1 rounded text-[11px]">
                          Milestone {milestone.id}: {milestone.name.split('–')[1] || milestone.name}
                        </span>
                      </div>
                    </div>

                    {/* Submission text & files */}
                    <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{milestone.submissionTitle}</span>
                        <span className="text-slate-500 font-mono text-[11px]">Submitted: {milestone.submissionDate}</span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{milestone.submissionDescription}</p>

                      {milestone.uploadedFiles && milestone.uploadedFiles.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                          {milestone.uploadedFiles.map((f, i) => (
                            <span key={i} className="bg-slate-50 border border-slate-200 text-slate-700 px-2 py-1 rounded flex items-center gap-1 font-mono text-[11px]">
                              <FileText className="w-3.5 h-3.5 text-sky-600" />
                              {f.fileName} ({f.fileSize})
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Review Action Trigger */}
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        onClick={() => {
                          setReviewModalData({ project, milestone });
                          setReviewAction('Approved');
                          setReviewComments('Deliverables thoroughly verified against district technical requirements.');
                        }}
                        className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold flex items-center gap-1 transition-colors"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approve Submission</span>
                      </button>

                      <button
                        onClick={() => {
                          setReviewModalData({ project, milestone });
                          setReviewAction('Rejected');
                          setRejectionReason('Incomplete firmware test metrics.');
                          setReviewComments('Please include the power consumption logs and resubmit.');
                        }}
                        className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold flex items-center gap-1 transition-colors"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject & Request Revision</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PROJECT MANAGEMENT (SRS Section 21 & 22) */}
      {adminTab === 'projects' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                District Problem Statements Management
              </h2>
              <p className="text-xs text-slate-500">
                Create, edit, archive, or delete problem statements (SRS Section 21)
              </p>
            </div>
            <button
              onClick={handleOpenCreateProject}
              className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Create Project</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">Project ID</th>
                  <th className="py-3 px-4">Title</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Assigned Institution</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {projects.map(proj => (
                  <tr key={proj.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">{proj.id}</td>
                    <td className="py-3 px-4 font-medium text-slate-900 max-w-xs truncate">{proj.title}</td>
                    <td className="py-3 px-4 text-slate-600">{proj.department}</td>
                    <td className="py-3 px-4 text-slate-600">{proj.technologyCategory}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                        proj.status === 'Available' ? 'bg-emerald-50 text-emerald-700' :
                        proj.status === 'In Progress' ? 'bg-sky-50 text-sky-700' :
                        proj.status === 'Completed' ? 'bg-slate-100 text-slate-700' :
                        'bg-amber-50 text-amber-700'
                      }`}>
                        {proj.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {proj.selectedByInstitutionName || '— Unselected —'}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEditProject(proj)}
                          className="p-1.5 text-slate-600 hover:text-sky-700 hover:bg-sky-50 rounded"
                          title="Edit Problem Statement"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => archiveProject(proj.id)}
                          className="p-1.5 text-slate-600 hover:text-amber-700 hover:bg-amber-50 rounded"
                          title="Archive Project"
                        >
                          <Archive className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Permanently delete project ${proj.id}?`)) {
                              deleteProject(proj.id);
                            }
                          }}
                          className="p-1.5 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded"
                          title="Delete Project"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: COLLECTOR ANALYTICS VIEW */}
      {adminTab === 'analytics' && (
        <CollectorDashboard onOpenCertificates={onOpenCertificates} />
      )}

      {/* TAB 4: INSTITUTION MANAGEMENT (SRS Section 22) */}
      {adminTab === 'institutions' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-5 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900">
              Registered Academic Institutions ({institutions.length})
            </h2>
            <p className="text-xs text-slate-500">
              Surveillance of college coordinators, NAAC ratings, and active project commitments
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Institution Name</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">NAAC</th>
                  <th className="py-3 px-4">Coordinator</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Active Project</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {institutions.map(inst => {
                  const prj = projects.find(p => p.selectedByInstitutionId === inst.id);
                  return (
                    <tr key={inst.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{inst.code}</td>
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {inst.name} ({inst.shortName})
                      </td>
                      <td className="py-3 px-4 text-slate-600">{inst.institutionType}</td>
                      <td className="py-3 px-4 font-bold text-slate-800">{inst.naacGrade}</td>
                      <td className="py-3 px-4 text-slate-600">
                        <div>{inst.coordinatorName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{inst.coordinatorEmail}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          inst.status === 'Active' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {inst.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {prj ? prj.id : '— None —'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: MENTOR MANAGEMENT & PAIRING (SRS Section 22) */}
      {adminTab === 'mentors' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-5 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900">
              Industry Mentors & Technical Pairing
            </h2>
            <p className="text-xs text-slate-500">
              Assign corporate domain experts to collegiate engineering problem statements
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">Mentor Name</th>
                  <th className="py-3 px-4">Organization</th>
                  <th className="py-3 px-4">Designation</th>
                  <th className="py-3 px-4">Expertise</th>
                  <th className="py-3 px-4">Exp</th>
                  <th className="py-3 px-4">Assigned Projects</th>
                  <th className="py-3 px-4 text-right">Pairing Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {mentors.map(m => {
                  const assigned = projects.filter(p => p.assignedMentorId === m.id);

                  return (
                    <tr key={m.id} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-bold text-slate-900">{m.fullName}</td>
                      <td className="py-3 px-4 font-medium text-slate-800">{m.organization}</td>
                      <td className="py-3 px-4 text-slate-600">{m.designation}</td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {m.expertise.map(exp => (
                            <span key={exp} className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                              {exp}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono">{m.yearsOfExperience} yrs</td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {assigned.map(p => p.id).join(', ') || '— None —'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => {
                            setSelectedMentorId(m.id);
                            setAssignModalProject(projects[0]);
                          }}
                          className="text-xs text-purple-700 hover:text-purple-900 font-semibold underline"
                        >
                          Pair to Project
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: AUDIT LOGS (SRS Section 24 & 25) */}
      {adminTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="p-5 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                System Audit Trail (SRS Section 24 & 25)
              </h2>
              <p className="text-xs text-slate-500">
                Immutable records tracking Login, Project Creation, Project Updates, Milestone Reviews, and Certificate Generation
              </p>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              Total Logged: {auditLogs.length}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Tracked Action</th>
                  <th className="py-3 px-4">User / Actor</th>
                  <th className="py-3 px-4">Previous Value</th>
                  <th className="py-3 px-4">New Value</th>
                  <th className="py-3 px-4">Details</th>
                  <th className="py-3 px-4">IP Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50 font-mono text-[11px]">
                    <td className="py-3 px-4 whitespace-nowrap text-slate-500">{log.timestamp}</td>
                    <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        log.userAction === 'Milestone Reviews' ? 'bg-sky-100 text-sky-800' :
                        log.userAction === 'Certificate Generation' ? 'bg-emerald-100 text-emerald-800' :
                        log.userAction === 'Project Creation' ? 'bg-purple-100 text-purple-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {log.userAction}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans text-slate-800 whitespace-nowrap">{log.performedBy}</td>
                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate">{log.previousValue || '—'}</td>
                    <td className="py-3 px-4 font-semibold text-slate-800 max-w-xs truncate">{log.newValue || '—'}</td>
                    <td className="py-3 px-4 font-sans text-slate-600 max-w-xs truncate">{log.details}</td>
                    <td className="py-3 px-4 text-slate-400">{log.ipAddress || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: HERO SLIDESHOW & PICTURES MANAGER */}
      {adminTab === 'slides' && <HeroSlideshowManager />}

      {/* TAB: FAQ & CONTACT MANAGER */}
      {adminTab === 'faq-contact' && <FaqContactManager />}

      {/* MODAL 1: Milestone Review Modal (SRS Section 15) */}
      {reviewModalData && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            
            <div className="bg-purple-50 border-b border-purple-100 px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Super Admin Milestone Review Decision
                </h3>
                <p className="text-xs text-slate-500">
                  {reviewModalData.project.id} · Milestone {reviewModalData.milestone.id}
                </p>
              </div>
              <button
                onClick={() => setReviewModalData(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleProcessReview} className="p-6 space-y-4 text-xs">
              
              {/* Submission recap */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <span className="font-semibold text-slate-800 block">
                  Title: {reviewModalData.milestone.submissionTitle}
                </span>
                <p className="text-slate-600 leading-relaxed">
                  {reviewModalData.milestone.submissionDescription}
                </p>
              </div>

              {/* Review Action (Approve vs Reject) */}
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Determination <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setReviewAction('Approved')}
                    className={`py-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 border transition-colors ${
                      reviewAction === 'Approved'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-700 border-slate-300'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve Milestone</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setReviewAction('Rejected')}
                    className={`py-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 border transition-colors ${
                      reviewAction === 'Rejected'
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'bg-white text-slate-700 border-slate-300'
                    }`}
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Reject & Request Revision</span>
                  </button>
                </div>
              </div>

              {/* If Rejected: Mandatory Rejection Reason per SRS Section 15 */}
              {reviewAction === 'Rejected' && (
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Rejection Reason <span className="text-rose-500">* (Mandatory per SRS Section 15)</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Incomplete test evidence / missing circuit schematics"
                    value={rejectionReason}
                    onChange={e => setRejectionReason(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>
              )}

              {/* Review Comments */}
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Review Comments {reviewAction === 'Rejected' && <span className="text-rose-500">*</span>}
                </label>
                <textarea
                  rows={3}
                  required={reviewAction === 'Rejected'}
                  placeholder="Official comments provided back to the institution and student team..."
                  value={reviewComments}
                  onChange={e => setReviewComments(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setReviewModalData(null)}
                  className="px-4 py-2 text-slate-600 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-white font-semibold rounded-lg shadow-xs ${
                    reviewAction === 'Approved' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  Finalize Decision
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* MODAL 2: Create / Edit Project Form (SRS Section 21 & 22) */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            
            <div className="bg-purple-50 border-b border-purple-100 px-6 py-4 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingProjectId ? `Edit Problem Statement (${editingProjectId})` : 'Create New District Problem Statement'}
              </h3>
              <button
                onClick={() => setIsProjectModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProject} className="p-6 max-h-[75vh] overflow-y-auto space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Project ID</label>
                  <input
                    type="text"
                    required
                    disabled={!!editingProjectId}
                    value={projectForm.id}
                    onChange={e => setProjectForm({ ...projectForm, id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-medium mb-1">Project Title <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Automated Sluice Gate Control"
                    value={projectForm.title}
                    onChange={e => setProjectForm({ ...projectForm, title: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Department</label>
                  <input
                    type="text"
                    required
                    value={projectForm.department}
                    onChange={e => setProjectForm({ ...projectForm, department: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Sector</label>
                  <input
                    type="text"
                    required
                    value={projectForm.sector}
                    onChange={e => setProjectForm({ ...projectForm, sector: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">Technology Category</label>
                  <select
                    value={projectForm.technologyCategory}
                    onChange={e => setProjectForm({ ...projectForm, technologyCategory: e.target.value as TechnologyCategory })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md bg-white"
                  >
                    <option value="Software">Software</option>
                    <option value="Hardware">Hardware</option>
                    <option value="Embedded">Embedded</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Complete Problem Statement Description <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Comprehensive district background, current operational bottlenecks, and requested solution..."
                  value={projectForm.description}
                  onChange={e => setProjectForm({ ...projectForm, description: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Objectives (One per line)
                  </label>
                  <textarea
                    rows={3}
                    value={projectForm.objectivesText}
                    onChange={e => setProjectForm({ ...projectForm, objectivesText: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Expected Deliverables (One per line)
                  </label>
                  <textarea
                    rows={3}
                    value={projectForm.deliverablesText}
                    onChange={e => setProjectForm({ ...projectForm, deliverablesText: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Required Skills & Technologies (Comma-separated)
                </label>
                <input
                  type="text"
                  placeholder="Python, Embedded C, LoRaWAN, React, CAD"
                  value={projectForm.skillsText}
                  onChange={e => setProjectForm({ ...projectForm, skillsText: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsProjectModalOpen(false)}
                  className="px-4 py-2 text-slate-600 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg shadow-xs"
                >
                  Save Problem Statement
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Pair Mentor to Project */}
      {assignModalProject && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-slate-900">
              Pair Industry Mentor to {assignModalProject.id}
            </h3>
            <p className="text-slate-600">
              Select an industry domain expert to guide collegiate team working on "{assignModalProject.title}".
            </p>

            <div>
              <label className="block text-slate-700 font-medium mb-1">Select Mentor</label>
              <select
                value={selectedMentorId}
                onChange={e => setSelectedMentorId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md bg-white"
              >
                <option value="">— Choose a Mentor —</option>
                {mentors.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.organization}) · {m.expertise.join(', ')}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setAssignModalProject(null)}
                className="px-3 py-1.5 text-slate-600"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!selectedMentorId}
                onClick={() => {
                  assignMentorToProject(assignModalProject.id, selectedMentorId);
                  setAssignModalProject(null);
                }}
                className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-md disabled:opacity-40"
              >
                Confirm Pairing
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
