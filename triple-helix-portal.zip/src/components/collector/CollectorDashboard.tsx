import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Building2, 
  Users, 
  Layers, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  BarChart3, 
  TrendingUp, 
  UserCheck, 
  Sparkles,
  Search,
  Filter,
  Eye,
  Award
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

interface Props {
  onOpenCertificates?: (projectId: string) => void;
}

export const CollectorDashboard: React.FC<Props> = ({ onOpenCertificates }) => {
  const { institutions, mentors, projects } = useApp();

  // Active Monitoring Sub-view: 'progress' | 'milestones' | 'institutions'
  const [monitoringView, setMonitoringView] = useState<'progress' | 'milestones' | 'institutions'>('progress');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  // 1. Summary Cards Metrics (SRS Section 20)
  const totalInstitutions = institutions.length;
  const totalMentors = mentors.length;
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'In Progress').length;
  const completedProjects = projects.filter(p => p.status === 'Completed').length;

  // 2. Chart.js Analytics Data (SRS Section 20)
  // A. Department-wise Projects
  const deptMap: Record<string, number> = {};
  projects.forEach(p => {
    deptMap[p.department] = (deptMap[p.department] || 0) + 1;
  });
  const deptLabels = Object.keys(deptMap);
  const deptCounts = Object.values(deptMap);

  const deptChartData = {
    labels: deptLabels,
    datasets: [
      {
        label: 'Projects by Department',
        data: deptCounts,
        backgroundColor: [
          'rgba(2, 132, 199, 0.8)',
          'rgba(14, 165, 233, 0.8)',
          'rgba(56, 189, 248, 0.8)',
          'rgba(99, 102, 241, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)'
        ],
        borderColor: '#ffffff',
        borderWidth: 1.5,
        borderRadius: 6
      }
    ]
  };

  // B. Completion Rates (Status Breakdown)
  const completionData = {
    labels: ['Available', 'In Progress', 'Completed'],
    datasets: [
      {
        data: [
          projects.filter(p => p.status === 'Available').length,
          activeProjects,
          completedProjects
        ],
        backgroundColor: ['#94a3b8', '#0284c7', '#10b981'],
        borderWidth: 2,
        borderColor: '#ffffff'
      }
    ]
  };

  // C. Institution Participation
  const instNames = institutions.map(i => i.shortName);
  const instProjectCount = institutions.map(i => {
    return projects.filter(p => p.selectedByInstitutionId === i.id).length;
  });

  const institutionChartData = {
    labels: instNames,
    datasets: [
      {
        label: 'Selected Projects',
        data: instProjectCount,
        backgroundColor: 'rgba(3, 105, 161, 0.8)',
        borderRadius: 6
      }
    ]
  };

  // D. Mentor Participation
  const mentorDomainMap: Record<string, number> = {};
  mentors.forEach(m => {
    m.expertise.forEach(e => {
      mentorDomainMap[e] = (mentorDomainMap[e] || 0) + 1;
    });
  });

  const mentorChartData = {
    labels: Object.keys(mentorDomainMap).slice(0, 6),
    datasets: [
      {
        label: 'Mentors by Expertise Domain',
        data: Object.values(mentorDomainMap).slice(0, 6),
        backgroundColor: 'rgba(16, 185, 129, 0.8)',
        borderRadius: 6
      }
    ]
  };

  // Filtered monitoring projects
  const filteredProjects = projects.filter(p => {
    if (departmentFilter !== 'All' && p.department !== departmentFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return p.title.toLowerCase().includes(q) || p.id.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sky-400 text-xs font-semibold uppercase tracking-wider">
              <UserCheck className="w-4 h-4" />
              <span>District Administration Oversight</span>
              <span>·</span>
              <span className="text-amber-400 font-medium">Read-Only Analytics (Strict Access Control)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold">
              District Collector Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              High-level administrative monitoring of collegiate engineering innovation, cross-departmental adoption, and student milestone velocity across Coimbatore District.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs bg-white/10 px-3 py-2 rounded-lg border border-white/20 text-slate-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Audited Gov Data Pipeline</span>
          </div>
        </div>
      </div>

      {/* 1. Summary Cards (5 Metrics explicitly specified in SRS Section 20) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* Total Institutions */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Institutions</span>
            <Building2 className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 tabular-nums">
            {totalInstitutions}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Accredited Colleges</span>
        </div>

        {/* Total Mentors */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Mentors</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 tabular-nums">
            {totalMentors}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Industry Experts</span>
        </div>

        {/* Total Projects */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Projects</span>
            <Layers className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 tabular-nums">
            {totalProjects}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Problem Statements</span>
        </div>

        {/* Active Projects */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Active Projects</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 tabular-nums">
            {activeProjects}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Under Development</span>
        </div>

        {/* Completed Projects */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Completed Projects</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 tabular-nums">
            {completedProjects}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Certificates Issued</span>
        </div>

      </div>

      {/* 2. Analytics Charts (SRS Section 20 - Chart.js) */}
      <div className="space-y-4">
        <div className="border-b border-slate-200 pb-2 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-sky-600" />
            <span>District Innovation Analytics (Chart.js Visualizations)</span>
          </h2>
          <span className="text-xs text-slate-400">Rendered via Chart.js engine</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Chart 1: Department-wise Projects */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                1. Department-Wise Projects
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Count</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              <Bar 
                data={deptChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: { stepSize: 1 }
                    }
                  }
                }} 
              />
            </div>
          </div>

          {/* Chart 2: Completion Rates */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                2. Completion Rates & Pipeline Status
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Proportion</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              <Doughnut 
                data={completionData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: 'bottom' }
                  }
                }} 
              />
            </div>
          </div>

          {/* Chart 3: Institution Participation */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                3. Institution Participation
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Active Teams</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              <Bar 
                data={institutionChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: { stepSize: 1 }
                    }
                  }
                }} 
              />
            </div>
          </div>

          {/* Chart 4: Mentor Participation */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                4. Mentor Domain Participation
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">Expert Pool</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              <Bar 
                data={mentorChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { display: false }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: { stepSize: 1 }
                    }
                  }
                }} 
              />
            </div>
          </div>

        </div>
      </div>

      {/* 3. Monitoring Views (SRS Section 20: Project Progress, Milestone Status, Institution Performance) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs space-y-4 p-5">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              District Monitoring Matrix
            </h2>
            <p className="text-xs text-slate-500">
              Real-time surveillance across projects, milestones, and institution track records
            </p>
          </div>

          {/* Sub-view switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setMonitoringView('progress')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                monitoringView === 'progress' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Project Progress
            </button>
            <button
              onClick={() => setMonitoringView('milestones')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                monitoringView === 'milestones' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Milestone Status
            </button>
            <button
              onClick={() => setMonitoringView('institutions')}
              className={`px-3 py-1.5 rounded-md transition-colors ${
                monitoringView === 'institutions' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Institution Performance
            </button>
          </div>
        </div>

        {/* View A: Project Progress */}
        {monitoringView === 'progress' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Project ID</th>
                  <th className="py-2.5 px-3">Problem Title</th>
                  <th className="py-2.5 px-3">Department</th>
                  <th className="py-2.5 px-3">Selected Institution</th>
                  <th className="py-2.5 px-3">Assigned Mentor</th>
                  <th className="py-2.5 px-3">Progress</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProjects.map(p => {
                  const approvedCount = p.milestones.filter(m => m.status === 'Approved').length;
                  const pct = Math.round((approvedCount / 3) * 100);

                  return (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-mono font-bold text-slate-800">{p.id}</td>
                      <td className="py-3 px-3 font-medium text-slate-900 max-w-xs truncate">{p.title}</td>
                      <td className="py-3 px-3 text-slate-600">{p.department}</td>
                      <td className="py-3 px-3 text-slate-800 font-medium">
                        {p.selectedByInstitutionName || '— Unselected —'}
                      </td>
                      <td className="py-3 px-3 text-slate-600">
                        {p.assignedMentorName || '— Unassigned —'}
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div className="bg-sky-600 h-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="font-mono text-[11px] text-slate-600">{pct}%</span>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                          p.status === 'Completed' ? 'bg-emerald-50 text-emerald-700' :
                          p.status === 'In Progress' ? 'bg-sky-50 text-sky-700' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* View B: Milestone Status Detailed Breakdown */}
        {monitoringView === 'milestones' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Project ID</th>
                  <th className="py-2.5 px-3">Institution</th>
                  <th className="py-2.5 px-3">Milestone 1 (Docs)</th>
                  <th className="py-2.5 px-3">Milestone 2 (Dev)</th>
                  <th className="py-2.5 px-3">Milestone 3 (Final)</th>
                  <th className="py-2.5 px-3">Certificate Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {projects.filter(p => p.selectedByInstitutionId).map(p => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-mono font-bold text-slate-800">{p.id}</td>
                    <td className="py-3 px-3 font-medium text-slate-900">{p.selectedByInstitutionName}</td>
                    
                    {/* M1 */}
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        p.milestones[0]?.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' :
                        p.milestones[0]?.status === 'Submitted' ? 'bg-sky-100 text-sky-800' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {p.milestones[0]?.status}
                      </span>
                    </td>

                    {/* M2 */}
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        p.milestones[1]?.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' :
                        p.milestones[1]?.status === 'Submitted' ? 'bg-sky-100 text-sky-800' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {p.milestones[1]?.status}
                      </span>
                    </td>

                    {/* M3 */}
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        p.milestones[2]?.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' :
                        p.milestones[2]?.status === 'Submitted' ? 'bg-sky-100 text-sky-800' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {p.milestones[2]?.status}
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      {p.status === 'Completed' ? (
                        <button
                          onClick={() => onOpenCertificates?.(p.id)}
                          className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>View Certificates</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400">In Progress</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* View C: Institution Performance */}
        {monitoringView === 'institutions' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {institutions.map(inst => {
              const assignedPrj = projects.find(p => p.selectedByInstitutionId === inst.id);
              const isCompleted = assignedPrj?.status === 'Completed';

              return (
                <div key={inst.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{inst.name}</h4>
                      <span className="text-slate-500 font-mono text-[11px]">{inst.code} · NAAC {inst.naacGrade}</span>
                    </div>
                    <span className="bg-sky-100 text-sky-800 px-2 py-0.5 rounded font-semibold text-[10px]">
                      {inst.institutionType}
                    </span>
                  </div>

                  <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1">
                    <span className="text-slate-400 text-[10px] uppercase font-semibold block">
                      Active Engagement:
                    </span>
                    {assignedPrj ? (
                      <div>
                        <div className="font-semibold text-slate-900">{assignedPrj.title}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-1">
                          <span>Status: <strong>{assignedPrj.status}</strong></span>
                          <span>·</span>
                          <span>Dept: {assignedPrj.department}</span>
                        </div>
                      </div>
                    ) : (
                      <span className="text-slate-500 italic">No project currently locked</span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-slate-500 pt-1 text-[11px]">
                    <span>Coordinator: {inst.coordinatorName}</span>
                    <span>{inst.coordinatorPhone}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
};
