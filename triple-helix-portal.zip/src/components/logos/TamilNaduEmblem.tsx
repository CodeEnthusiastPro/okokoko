import React from 'react';
import tamilNaduEmblemImg from './TamilNaduEmblem.jpg';

interface Props {
  className?: string;
  size?: number;
}

export const TamilNaduEmblem: React.FC<Props> = ({ 
  className = '', 
  size = 52 
}) => {
  return (
    <img
      src={tamilNaduEmblemImg}
      alt="Government of Tamil Nadu Official Emblem"
      width={size}
      height={size}
      style={{ width: size, height: size }}
      className={`object-contain rounded-full shadow-xs shrink-0 select-none ${className}`}
      loading="eager"
    />
  );
};

export default TamilNaduEmblem;
