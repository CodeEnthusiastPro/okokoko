import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TamilNaduEmblem } from '../logos/TamilNaduEmblem';
import { TripleHelixLogo } from '../logos/TripleHelixLogo';
import { 
  Bell, 
  LogOut, 
  ChevronDown, 
  Building2, 
  Briefcase, 
  GraduationCap, 
  ShieldCheck,
  LogIn,
  UserPlus
} from 'lucide-react';
import { UserRole } from '../../types';

interface Props {
  onOpenNotifications?: () => void;
  onOpenLogin?: (role?: UserRole) => void;
  onOpenRegisterInstitution?: () => void;
  onOpenRegisterMentor?: () => void;
}

export const CommonHeader: React.FC<Props> = ({ 
  onOpenNotifications,
  onOpenLogin,
  onOpenRegisterInstitution,
  onOpenRegisterMentor
}) => {
  const { currentUser, logoutUser, activePage, setActivePage, notifications, switchRole } = useApp();
  const [authDropdownOpen, setAuthDropdownOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* Left Section: Both Official Logos side-by-side */}
        <div 
          onClick={() => setActivePage('home')}
          className="flex items-center gap-3.5 sm:gap-5 cursor-pointer group select-none transition-transform hover:opacity-95 shrink-0"
          title="Triple Helix Portal - Government of Tamil Nadu"
        >
          {/* Logo 1: Government of Tamil Nadu Emblem */}
          <div className="flex items-center">
            <TamilNaduEmblem size={46} />
          </div>

          {/* Thin Hairline Divider between the two official emblems */}
          <div className="h-9 w-px bg-slate-200" aria-hidden="true" />

          {/* Logo 2: Triple Helix Official Logo with Ribbon Bulb & Typography */}
          <div className="flex items-center">
            <TripleHelixLogo height={38} showText={true} />
          </div>
        </div>

        {/* Center / Navigation Links (Home, About, FAQ, Contact Us) */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setActivePage('home')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activePage === 'home'
                ? 'text-[#1769AA] bg-sky-50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => setActivePage('about')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activePage === 'about'
                ? 'text-[#1769AA] bg-sky-50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            About
          </button>

          <button
            onClick={() => setActivePage('faq')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activePage === 'faq'
                ? 'text-[#1769AA] bg-sky-50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            FAQ
          </button>

          <button
            onClick={() => setActivePage('contact')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activePage === 'contact'
                ? 'text-[#1769AA] bg-sky-50'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Contact Us
          </button>

          <button
            onClick={() => switchRole('institution')}
            className="px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all cursor-pointer hidden lg:inline-block"
            title="Browse all District Problem Statements"
          >
            Browse Problem Statements
          </button>
        </nav>

        {/* Right Section: Authentic Session OR Login / Register in Upper Nav Bar */}
        <div className="flex items-center gap-3">
          
          {currentUser ? (
            <div className="flex items-center gap-3">
              {/* Notification Bell */}
              {onOpenNotifications && (
                <button
                  onClick={onOpenNotifications}
                  className="relative p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                  title="Notifications"
                >
                  <Bell className="w-4 h-4 text-sky-600" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 bg-sky-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
              )}

              {/* Logged in User Badge */}
              <div 
                onClick={() => setActivePage(currentUser.role === 'student' ? 'workspace' : 'dashboard')}
                className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100 transition-colors"
              >
                <div className="w-6 h-6 rounded-full bg-sky-100 text-sky-800 flex items-center justify-center text-xs font-bold">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-bold text-slate-800 leading-none">
                    {currentUser.name.split(' ')[0]}
                  </div>
                  <div className="text-[10px] font-semibold text-sky-700 uppercase tracking-wider leading-none mt-0.5">
                    {currentUser.role}
                  </div>
                </div>
              </div>

              {/* Logout Button */}
              <button
                onClick={logoutUser}
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            /* Login / Register Dropdown in Upper Nav Bar Itself (Right Side) */
            <div className="relative flex items-center gap-2">
              
              <button
                onClick={() => setAuthDropdownOpen(!authDropdownOpen)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#1769AA] hover:bg-[#125386] text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Login / Register</span>
                <ChevronDown className="w-3.5 h-3.5 text-sky-200" />
              </button>

              {authDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setAuthDropdownOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-2 w-72 bg-white text-slate-800 rounded-2xl shadow-2xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block font-mono">
                        Select Stakeholder Role
                      </span>
                    </div>

                    {/* Institution Option */}
                    <div className="p-1.5 border-b border-slate-100">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-900 px-2 py-1">
                        <span className="flex items-center gap-1.5 text-sky-900">
                          <Building2 className="w-4 h-4 text-sky-600" />
                          Institution
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 mt-1">
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenLogin && onOpenLogin('institution');
                          }}
                          className="text-xs text-center py-1.5 bg-sky-50 text-sky-700 hover:bg-sky-100 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Login
                        </button>
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenRegisterInstitution && onOpenRegisterInstitution();
                          }}
                          className="text-xs text-center py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Register
                        </button>
                      </div>
                    </div>

                    {/* Mentor Option */}
                    <div className="p-1.5 border-b border-slate-100">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-900 px-2 py-1">
                        <span className="flex items-center gap-1.5 text-emerald-900">
                          <Briefcase className="w-4 h-4 text-emerald-600" />
                          Industry Mentor
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 mt-1">
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenLogin && onOpenLogin('mentor');
                          }}
                          className="text-xs text-center py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Login
                        </button>
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenRegisterMentor && onOpenRegisterMentor();
                          }}
                          className="text-xs text-center py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Register
                        </button>
                      </div>
                    </div>

                    {/* Student Option */}
                    <div className="p-1.5 border-b border-slate-100">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-900 px-2 py-1">
                        <span className="flex items-center gap-1.5 text-indigo-900">
                          <GraduationCap className="w-4 h-4 text-indigo-600" />
                          Student Roster
                        </span>
                        <span className="text-[10px] text-slate-400">Team Login</span>
                      </div>
                      <div className="mt-1">
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenLogin && onOpenLogin('student');
                          }}
                          className="w-full text-xs text-center py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Sign In via Register No.
                        </button>
                      </div>
                    </div>

                    {/* Administration Option */}
                    <div className="p-1.5">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-900 px-2 py-1">
                        <span className="flex items-center gap-1.5 text-purple-900">
                          <ShieldCheck className="w-4 h-4 text-purple-600" />
                          Administration
                        </span>
                        <span className="text-[10px] text-purple-600 font-semibold">Official</span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 mt-1">
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenLogin && onOpenLogin('superadmin');
                          }}
                          className="text-xs text-center py-1.5 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Super Admin
                        </button>
                        <button
                          onClick={() => {
                            setAuthDropdownOpen(false);
                            onOpenLogin && onOpenLogin('collector');
                          }}
                          className="text-xs text-center py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg font-bold transition-colors cursor-pointer"
                        >
                          Collector
                        </button>
                      </div>
                    </div>

                  </div>
                </>
              )}

            </div>
          )}

        </div>

      </div>

      {/* Mobile Nav Links Row */}
      <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-100 bg-slate-50/80 text-xs font-semibold">
        <button
          onClick={() => setActivePage('home')}
          className={`px-3 py-1 rounded-md transition-colors ${activePage === 'home' ? 'text-sky-800 font-bold' : 'text-slate-600'}`}
        >
          Home
        </button>
        <button
          onClick={() => setActivePage('about')}
          className={`px-3 py-1 rounded-md transition-colors ${activePage === 'about' ? 'text-sky-800 font-bold' : 'text-slate-600'}`}
        >
          About
        </button>
        <button
          onClick={() => setActivePage('faq')}
          className={`px-3 py-1 rounded-md transition-colors ${activePage === 'faq' ? 'text-sky-800 font-bold' : 'text-slate-600'}`}
        >
          FAQ
        </button>
        <button
          onClick={() => setActivePage('contact')}
          className={`px-3 py-1 rounded-md transition-colors ${activePage === 'contact' ? 'text-sky-800 font-bold' : 'text-slate-600'}`}
        >
          Contact Us
        </button>
      </div>
    </header>
  );
};

export default CommonHeader;
