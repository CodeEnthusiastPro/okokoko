import React from 'react';
import { useApp } from '../../context/AppContext';
import { Building, MapPin, Phone, Mail, ExternalLink } from 'lucide-react';
import { TamilNaduEmblem } from '../logos/TamilNaduEmblem';
import { TripleHelixLogo } from '../logos/TripleHelixLogo';

export const Footer: React.FC = () => {
  const { setActivePage } = useApp();

  return (
    <footer className="w-full bg-slate-900 text-slate-300 border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: Portal Official Branding with both Logos */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-4 bg-white/95 p-3 rounded-xl border border-slate-700/60 w-fit">
              <TamilNaduEmblem size={44} />
              <div className="h-8 w-px bg-slate-200" />
              <TripleHelixLogo height={38} showText={true} />
            </div>
            <p className="text-sm text-slate-400 max-w-md leading-relaxed">
              The Triple Helix Portal unites District Administration, Academic Institutions, and Industry Mentors to solve localized real-world challenges through structured student engineering projects and validated milestone governance.
            </p>
            <div className="text-xs text-sky-400 font-medium">
              Government of Tamil Nadu · District Innovation Mission Initiative
            </div>
          </div>

          {/* Col 2: Quick Links (SRS Section 5: Home, About, Login) */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button 
                  onClick={() => setActivePage('home')}
                  className="hover:text-white transition-colors text-slate-400"
                >
                  Home
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('about')}
                  className="hover:text-white transition-colors text-slate-400 cursor-pointer"
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('faq')}
                  className="hover:text-white transition-colors text-slate-400 cursor-pointer"
                >
                  FAQ
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('contact')}
                  className="hover:text-white transition-colors text-slate-400 cursor-pointer"
                >
                  Contact Us
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('login')}
                  className="hover:text-white transition-colors text-slate-400"
                >
                  Login
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('register-institution')}
                  className="hover:text-white transition-colors text-slate-400"
                >
                  Institution Registration
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActivePage('register-mentor')}
                  className="hover:text-white transition-colors text-slate-400"
                >
                  Mentor Registration
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact Information (SRS Section 5) */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              District Office Contact
            </h3>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-start gap-2.5">
                <Building className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span className="text-slate-300 font-medium">
                  District Innovation & e-Governance Cell
                </span>
              </div>
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <span>District Collectorate Complex, State Bank Road, Gopalapuram, Coimbatore - 641018, Tamil Nadu</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-slate-500 shrink-0" />
                <span>+91 422 2301114 / 2301115</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-slate-500 shrink-0" />
                <span>triplehelix.cbe@tn.gov.in</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright Notice (SRS Section 5) */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div>
            © {new Date().getFullYear()} Triple Helix Portal. District Innovation & Higher Education Initiative. All rights reserved.
          </div>
        </div>

      </div>
    </footer>
  );
};
