import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Project, MentorFeedback } from '../../types';
import { 
  Briefcase, 
  Building2, 
  Users, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  FileText, 
  Send,
  Sparkles,
  Layers,
  Download
} from 'lucide-react';

export const MentorDashboard: React.FC = () => {
  const { 
    currentUser, 
    projects, 
    institutions, 
    mentorFeedbacks, 
    submitMentorFeedback, 
    triggerError 
  } = useApp();

  // Scoped to projects assigned to this mentor (SRS Section 19)
  const assignedProjects = projects.filter(p => 
    p.assignedMentorId === currentUser?.mentorId || 
    p.assignedMentorName === currentUser?.name
  );

  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    assignedProjects[0]?.id || ''
  );

  const currentProject = projects.find(p => p.id === selectedProjectId) || assignedProjects[0];
  const institution = institutions.find(i => i.id === currentProject?.selectedByInstitutionId);
  const feedbacksForProject = mentorFeedbacks.filter(f => f.projectId === currentProject?.id);

  // Form State for Mentor Submission (Feedback + Recommendations)
  const [targetMilestoneId, setTargetMilestoneId] = useState<1 | 2 | 3>(1);
  const [feedbackText, setFeedbackText] = useState('');
  const [recommendationsText, setRecommendationsText] = useState('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!feedbackText.trim() || !recommendationsText.trim()) {
      triggerError('File Upload Errors', 'Both Feedback and Recommendations fields are required.');
      return;
    }

    if (!currentProject) return;

    submitMentorFeedback(
      currentProject.id,
      targetMilestoneId,
      feedbackText,
      recommendationsText
    );

    setFeedbackText('');
    setRecommendationsText('');
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 4000);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Mentor Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-emerald-300 text-xs font-semibold uppercase tracking-wider">
              <Briefcase className="w-4 h-4" />
              <span>Industry Mentor Workspace (SRS Section 19)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold">
              {currentUser?.name || 'Industry Mentor Console'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Provide technical guidance, architectural oversight, and engineering feedback to student teams working on district public challenges.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/20 text-center shrink-0">
            <span className="text-xs text-emerald-200 block uppercase font-mono">Assigned Projects</span>
            <span className="text-2xl font-bold font-mono text-white">
              {assignedProjects.length}
            </span>
          </div>
        </div>
      </div>

      {assignedProjects.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-3">
          <Briefcase className="w-10 h-10 text-slate-400 mx-auto" />
          <h2 className="text-lg font-bold text-slate-900">No Projects Currently Assigned</h2>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            The Super Admin assigns industry mentors to projects based on domain expertise matches. Once assigned, student team submissions will appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Assigned Projects List (SRS Section 19) */}
          <div className="space-y-4">
            <div className="border-b border-slate-200 pb-2">
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Assigned Projects ({assignedProjects.length})
              </h2>
              <p className="text-xs text-slate-500">
                Select a project to review milestones & submit guidance
              </p>
            </div>

            <div className="space-y-3">
              {assignedProjects.map(proj => {
                const isSelected = proj.id === currentProject?.id;
                const completedCount = proj.milestones.filter(m => m.status === 'Approved').length;

                return (
                  <div
                    key={proj.id}
                    onClick={() => setSelectedProjectId(proj.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-emerald-50/70 border-emerald-500 ring-2 ring-emerald-200 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-mono font-bold text-slate-700">{proj.id}</span>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        proj.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'
                      }`}>
                        {proj.status}
                      </span>
                    </div>

                    <h3 className="text-xs font-bold text-slate-900 line-clamp-2 mb-2">
                      {proj.title}
                    </h3>

                    <div className="text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
                      <span>{proj.selectedByInstitutionName}</span>
                      <span className="font-mono">{completedCount}/3 Milestones</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Project Details, Milestones & Mentor Submission Form */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Institution & Team Details Panel (SRS Section 19) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                    Active Project Context
                  </span>
                  <h2 className="text-base font-bold text-slate-900">
                    {currentProject.title}
                  </h2>
                </div>
                <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded">
                  {currentProject.technologyCategory}
                </span>
              </div>

              {/* Institution Information (SRS Section 19) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px] block">
                    Assigned Institution
                  </span>
                  <div className="font-bold text-slate-900">{institution?.name || currentProject.selectedByInstitutionName}</div>
                  <div className="text-slate-600">Coordinator: {institution?.coordinatorName || 'Prof. M. Sundararajan'}</div>
                  <div className="text-slate-500 font-mono">{institution?.coordinatorEmail}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px] block">
                    Student Team ({currentProject.team?.students.length || 0} Members)
                  </span>
                  <div className="font-bold text-slate-900">
                    Leader: {currentProject.team?.students.find(s => s.isLeader)?.fullName || 'Designated Leader'}
                  </div>
                  <div className="text-slate-600">
                    {currentProject.team?.students.map(s => s.fullName).join(', ')}
                  </div>
                </div>
              </div>
            </div>

            {/* Milestone Reviews Panel (SRS Section 19) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="text-sm font-bold text-slate-900">
                  Project Milestone Reviews & Deliverables
                </h3>
                <span className="text-xs text-slate-400">
                  Read & critique technical deliverables
                </span>
              </div>

              <div className="space-y-3">
                {currentProject.milestones.map(m => (
                  <div key={m.id} className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800">
                          Milestone {m.id}: {m.name}
                        </span>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                          m.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' :
                          m.status === 'Submitted' ? 'bg-sky-100 text-sky-800' :
                          'bg-slate-200 text-slate-700'
                        }`}>
                          {m.status}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500 font-mono">Due: {m.deadlineDate}</span>
                    </div>

                    {m.submissionTitle && (
                      <div className="bg-white p-2.5 rounded border border-slate-200">
                        <div className="font-semibold text-slate-900">{m.submissionTitle}</div>
                        <div className="text-slate-600 text-[11px] mt-0.5">{m.submissionDescription}</div>
                        
                        {/* Uploaded files download */}
                        {m.uploadedFiles && m.uploadedFiles.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2 pt-2 border-t border-slate-100">
                            {m.uploadedFiles.map((uf, i) => (
                              <button
                                key={i}
                                onClick={() => {
                                  const blob = new Blob([`Triple Helix File: ${uf.fileName}`], { type: 'text/plain' });
                                  const url = URL.createObjectURL(blob);
                                  const a = document.createElement('a');
                                  a.href = url;
                                  a.download = uf.fileName;
                                  a.click();
                                }}
                                className="text-[10px] bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2 py-1 rounded flex items-center gap-1 font-medium text-slate-700"
                              >
                                <FileText className="w-3 h-3 text-sky-600" />
                                <span>{uf.fileName}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Feedback & Recommendations Submission Form (SRS Section 19) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-600" />
                  <span>Submit Technical Feedback & Recommendations</span>
                </h3>
                <span className="text-xs text-slate-400">Communicated to student team</span>
              </div>

              {showSuccessToast && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3 rounded-lg flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Feedback and recommendations successfully published to student workspace.</span>
                </div>
              )}

              <form onSubmit={handleFeedbackSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Select Milestone Target
                  </label>
                  <select
                    value={targetMilestoneId}
                    onChange={e => setTargetMilestoneId(Number(e.target.value) as 1 | 2 | 3)}
                    className="w-full sm:w-60 px-3 py-2 border border-slate-300 rounded-md bg-white"
                  >
                    <option value={1}>Milestone 1 – Initial Documentation</option>
                    <option value={2}>Milestone 2 – Development Progress</option>
                    <option value={3}>Milestone 3 – Final Submission</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Technical Feedback (Critique on methodology & prototype) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Provide constructive assessment on circuit schematics, algorithms, sensor stability, or component selection..."
                    value={feedbackText}
                    onChange={e => setFeedbackText(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Actionable Recommendations (Design improvements & safety protocols) <span className="text-rose-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Specific actionable engineering recommendations (e.g. adding transient voltage suppression, testing LoRa link margin)..."
                    value={recommendationsText}
                    onChange={e => setRecommendationsText(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-2 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Mentor Guidance</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Prior Feedback History */}
            {feedbacksForProject.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-3 text-xs">
                <h4 className="font-bold text-slate-800">Your Submitted Feedback History:</h4>
                <div className="space-y-3">
                  {feedbacksForProject.map(fb => (
                    <div key={fb.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                      <div className="flex items-center justify-between text-slate-500">
                        <span className="font-semibold text-emerald-800">Milestone {fb.milestoneId} Review</span>
                        <span className="font-mono text-[11px]">{fb.submittedAt}</span>
                      </div>
                      <p className="text-slate-700"><strong>Feedback:</strong> {fb.feedback}</p>
                      <p className="text-slate-700"><strong>Recommendations:</strong> {fb.recommendations}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>
      )}

    </div>
  );
};
