import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Building2, 
  Landmark, 
  Briefcase, 
  ArrowLeft, 
  CheckCircle2
} from 'lucide-react';
import { TripleHelixEcosystemVisual } from './TripleHelixEcosystemVisual';
import { ProcessLifecycleVisual } from './ProcessLifecycleVisual';

export const AboutPage: React.FC = () => {
  const { setActivePage } = useApp();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, []);

  return (
    <div className="w-full min-h-screen py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation Bar Back Link & Official Tag */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActivePage('home')}
            className="inline-flex items-center gap-2 text-xs font-semibold text-[#10233F] hover:text-[#1769AA] transition-colors bg-white border border-slate-200 shadow-2xs hover:bg-slate-50 px-3.5 py-2 rounded-xl cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Portal</span>
          </button>

          <span className="text-xs font-mono font-medium text-slate-500 uppercase tracking-widest">
            Tamil Nadu District Innovation Ecosystem
          </span>
        </div>

        {/* ABOUT US Header Banner */}
        <div className="space-y-2 border-b border-slate-200 pb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md text-xs font-bold tracking-wider uppercase bg-[#EAF4FC] text-[#1769AA] border border-[#1769AA]/30">
            About Us
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#10233F] tracking-tight">
            The Triple Helix Innovation Framework
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-3xl leading-relaxed">
            Unifying District Administration, Higher Education Engineering Colleges, and Industry Mentors into a collaborative, real-world civic impact ecosystem.
          </p>
        </div>

        {/* Premium 16:9 Triple Helix Ecosystem Visual Showcase */}
        <section className="w-full">
          <TripleHelixEcosystemVisual />
        </section>

        {/* Section: The Three Tripartite Pillars */}
        <section className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Government (#1769AA) */}
            <div className="bg-[#EAF4FC]/70 border border-[#1769AA]/30 rounded-2xl p-6 space-y-3 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-white border border-[#1769AA]/20 flex items-center justify-center text-[#1769AA] shadow-2xs">
                <Landmark className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-[#10233F]">
                1. Government (Collectorate)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Identifies critical district-level pain points, uploads vetted problem statements, manages regulatory permissions, and deploys completed solutions for citizen welfare.
              </p>
            </div>

            {/* Academia (#2E8B57) */}
            <div className="bg-[#EAF6EF]/70 border border-[#2E8B57]/30 rounded-2xl p-6 space-y-3 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-white border border-[#2E8B57]/20 flex items-center justify-center text-[#2E8B57] shadow-2xs">
                <Building2 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-[#10233F]">
                2. Academia (Institutions)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Accredited colleges field faculty-supervised student engineering teams to apply cutting-edge software, embedded firmware, and mechanical prototyping to local challenges.
              </p>
            </div>

            {/* Industry (#D49A24) */}
            <div className="bg-[#FFF5DD]/70 border border-[#D49A24]/30 rounded-2xl p-6 space-y-3 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-white border border-[#D49A24]/20 flex items-center justify-center text-[#D49A24] shadow-2xs">
                <Briefcase className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-[#10233F]">
                3. Industry (Mentors)
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Domain experts from top engineering conglomerates guide students on industrial-grade architectures, reliability, design for manufacturing, and cybersecurity best practices.
              </p>
            </div>

          </div>
        </section>

        {/* Section: Objectives (SRS Section 6) */}
        <section className="space-y-6 bg-white/80 backdrop-blur-md border border-slate-200/90 rounded-3xl p-8 sm:p-10 shadow-sm relative overflow-hidden">
          <div className="space-y-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Strategic Mandates
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Core Objectives
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sky-800 font-bold text-base">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                <span>Solve District Problems</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Directly address grass-root public infrastructure, agricultural water allocation, waste segregation, and community health bottlenecks using indigenous engineering.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sky-800 font-bold text-base">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                <span>Promote Innovation</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Transform academic capstone engineering projects from theoretical textbook exercises into tangible, field-tested prototypes with demonstrable societal utility.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sky-800 font-bold text-base">
                <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                <span>Encourage Industry Participation</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Engage senior corporate engineering leaders in mentoring regional student talent, fostering regional intellectual property creation and talent pipelines.
              </p>
            </div>
          </div>
        </section>

        {/* Section: Workflow Process Lifecycle Visual Showcase */}
        <section className="w-full">
          <ProcessLifecycleVisual />
        </section>

        {/* Call to Action */}
        <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-slate-600">
            Ready to participate in district problem solving?
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActivePage('register-institution')}
              className="text-xs font-semibold px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg transition-colors"
            >
              Register as Institution
            </button>
            <button
              onClick={() => setActivePage('register-mentor')}
              className="text-xs font-semibold px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
            >
              Register as Mentor
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
