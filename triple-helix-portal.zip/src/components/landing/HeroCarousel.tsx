import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Pause, 
  Play, 
  ArrowRight, 
  ExternalLink,
  ShieldCheck,
  Cpu
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { HeroSlide, UserRole } from '../../types';

interface HeroCarouselProps {
  onOpenLogin?: (role?: UserRole) => void;
  onOpenRegisterInstitution?: () => void;
  onOpenRegisterMentor?: () => void;
}

export const HeroCarousel: React.FC<HeroCarouselProps> = ({
  onOpenLogin,
  onOpenRegisterInstitution,
  onOpenRegisterMentor
}) => {
  const { heroSlides, setActivePage, switchRole } = useApp();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  // Filter only active slides
  const activeSlides: HeroSlide[] = heroSlides.filter(s => s.active);
  const totalSlides = activeSlides.length > 0 ? activeSlides.length : 1;

  // Auto-play interval
  useEffect(() => {
    if (!isPlaying || activeSlides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentSlideIndex(prev => (prev + 1) % activeSlides.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [isPlaying, activeSlides.length]);

  // Current active slide with safe fallback
  const slide: HeroSlide = activeSlides[currentSlideIndex] || {
    id: 'fallback-01',
    badge: 'Coimbatore District Innovation Mission',
    headlineMain: 'Your Engineering Innovation Is Just',
    headlineHighlight: 'A Milestone Away',
    description: 'Connecting accredited engineering colleges and industry leaders with verified District Administration problem statements across Coimbatore District.',
    primaryCtaText: 'Explore Problem Statements',
    primaryCtaAction: 'browse',
    secondaryCtaText: 'Learn More',
    secondaryCtaAction: 'about',
    theme: 'amber',
    category: 'District Innovation',
    active: true,
    departmentTag: 'District Collectorate IT & e-Governance Cell',
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Engineering innovation lab',
    imageCaption: 'Collegiate Engineering Laboratories · Hardware Prototyping'
  };

  const nextSlide = () => {
    setCurrentSlideIndex(prev => (prev + 1) % activeSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlideIndex(prev => (prev - 1 + activeSlides.length) % activeSlides.length);
  };

  // Theme styling configurations with rich, vibrant gradients
  const getThemeStyles = (theme: HeroSlide['theme']) => {
    switch (theme) {
      case 'amber':
        return {
          bgGradient: 'from-slate-950 via-amber-950/60 to-slate-900',
          accentText: 'text-amber-400',
          highlightGradient: 'from-amber-300 via-orange-300 to-yellow-200',
          badgeBorder: 'border-amber-500/40 bg-amber-950/50 text-amber-300',
          glowColor: 'rgba(245, 158, 11, 0.28)',
          buttonPrimary: 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold',
          imageBorder: 'border-amber-500/40 ring-2 ring-amber-500/25 shadow-amber-500/10'
        };
      case 'emerald':
        return {
          bgGradient: 'from-slate-950 via-emerald-950/60 to-teal-950',
          accentText: 'text-emerald-400',
          highlightGradient: 'from-emerald-300 via-teal-300 to-cyan-200',
          badgeBorder: 'border-emerald-500/40 bg-emerald-950/50 text-emerald-300',
          glowColor: 'rgba(16, 185, 129, 0.28)',
          buttonPrimary: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold',
          imageBorder: 'border-emerald-500/40 ring-2 ring-emerald-500/25 shadow-emerald-500/10'
        };
      case 'sky':
        return {
          bgGradient: 'from-slate-950 via-sky-950/60 to-blue-950',
          accentText: 'text-sky-400',
          highlightGradient: 'from-sky-300 via-blue-300 to-indigo-200',
          badgeBorder: 'border-sky-500/40 bg-sky-950/50 text-sky-300',
          glowColor: 'rgba(14, 165, 233, 0.28)',
          buttonPrimary: 'bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold',
          imageBorder: 'border-sky-500/40 ring-2 ring-sky-500/25 shadow-sky-500/10'
        };
      case 'purple':
        return {
          bgGradient: 'from-slate-950 via-purple-950/60 to-indigo-950',
          accentText: 'text-purple-400',
          highlightGradient: 'from-purple-300 via-pink-300 to-indigo-200',
          badgeBorder: 'border-purple-500/40 bg-purple-950/50 text-purple-300',
          glowColor: 'rgba(168, 85, 247, 0.28)',
          buttonPrimary: 'bg-purple-500 hover:bg-purple-400 text-white font-bold',
          imageBorder: 'border-purple-500/40 ring-2 ring-purple-500/25 shadow-purple-500/10'
        };
      case 'indigo':
      default:
        return {
          bgGradient: 'from-slate-950 via-indigo-950/60 to-slate-900',
          accentText: 'text-indigo-400',
          highlightGradient: 'from-indigo-300 via-sky-300 to-cyan-200',
          badgeBorder: 'border-indigo-500/40 bg-indigo-950/50 text-indigo-300',
          glowColor: 'rgba(99, 102, 241, 0.28)',
          buttonPrimary: 'bg-indigo-500 hover:bg-indigo-400 text-white font-bold',
          imageBorder: 'border-indigo-500/40 ring-2 ring-indigo-500/25 shadow-indigo-500/10'
        };
    }
  };

  const themeStyles = getThemeStyles(slide.theme);

  // Handle CTA navigation
  const handleCta = (action: string) => {
    switch (action) {
      case 'browse':
        switchRole('institution');
        break;
      case 'login':
        onOpenLogin ? onOpenLogin('institution') : setActivePage('login');
        break;
      case 'register-institution':
        onOpenRegisterInstitution ? onOpenRegisterInstitution() : setActivePage('register-institution');
        break;
      case 'register-mentor':
        onOpenRegisterMentor ? onOpenRegisterMentor() : setActivePage('register-mentor');
        break;
      case 'about':
        setActivePage('about');
        break;
      default:
        switchRole('institution');
        break;
    }
  };

  const currentImageUrl = slide.imageUrl || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1000&q=80';

  return (
    <div 
      className="relative w-full overflow-hidden rounded-2xl sm:rounded-3xl border border-slate-800 bg-slate-950 shadow-2xl transition-all"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
    >
      {/* Background Gradient & Ambient Glow */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`bg-${slide.id}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7 }}
          className={`absolute inset-0 bg-gradient-to-br ${themeStyles.bgGradient}`}
        >
          {/* Subtle Isometric Blueprint Grid */}
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `linear-gradient(to right, rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.08) 1px, transparent 1px)`,
              backgroundSize: '32px 32px'
            }}
          />
          {/* Radial Ambient Glow */}
          <div 
            className="absolute -top-24 -right-24 w-96 h-96 rounded-full blur-3xl pointer-events-none"
            style={{ background: themeStyles.glowColor }}
          />
          <div 
            className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full blur-3xl pointer-events-none"
            style={{ background: themeStyles.glowColor }}
          />
        </motion.div>
      </AnimatePresence>

      {/* Slide Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 py-10 sm:py-14 min-h-[460px] flex flex-col justify-between">
        
        {/* Top Header Bar inside Showcase */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4 mb-6">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-sky-400" />
            <span className="text-xs font-mono uppercase tracking-widest text-slate-300">
              {slide.departmentTag || 'District Innovation Portal'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono font-semibold px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300">
              Slide {currentSlideIndex + 1} of {totalSlides}
            </span>
          </div>
        </div>

        {/* Main Content Layout: Left Text & Right Featured Picture */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center flex-1 my-auto">
          
          {/* Left Column (7 cols): High-Impact Typography & Action Buttons */}
          <div className="lg:col-span-7 space-y-5 text-left">
            
            {/* Category / Institutional Badge */}
            <motion.div
              key={`badge-${slide.id}`}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className={`inline-flex items-center gap-2 px-3 py-1 rounded-md text-xs font-semibold tracking-wide border ${themeStyles.badgeBorder}`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>{slide.badge}</span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              key={`title-${slide.id}`}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.08 }}
              className="text-2xl sm:text-3xl lg:text-4xl xl:text-[42px] font-extrabold text-white tracking-tight leading-[1.18]"
            >
              <span>{slide.headlineMain} </span>
              <span className={`bg-gradient-to-r ${themeStyles.highlightGradient} bg-clip-text text-transparent underline decoration-white/20 underline-offset-4`}>
                {slide.headlineHighlight}
              </span>
            </motion.h1>

            {/* Description */}
            <motion.p
              key={`desc-${slide.id}`}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.16 }}
              className="text-sm sm:text-base text-slate-300/95 leading-relaxed max-w-2xl font-normal"
            >
              {slide.description}
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              key={`cta-${slide.id}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.24 }}
              className="flex flex-wrap items-center gap-3 pt-2"
            >
              <button
                onClick={() => handleCta(slide.primaryCtaAction)}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm shadow-lg transition-transform hover:scale-[1.02] active:scale-95 cursor-pointer ${themeStyles.buttonPrimary}`}
              >
                <span>{slide.primaryCtaText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => handleCta(slide.secondaryCtaAction)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-white/10 hover:bg-white/15 text-white border border-white/20 transition-all cursor-pointer"
              >
                <span>{slide.secondaryCtaText}</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </motion.div>

          </div>

          {/* Right Column (5 cols): High-Resolution Featured Picture Showcase */}
          <div className="lg:col-span-5">
            <motion.div
              key={`image-${slide.id}`}
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.12 }}
              className={`relative overflow-hidden rounded-2xl sm:rounded-3xl border bg-slate-900 shadow-2xl group ${themeStyles.imageBorder}`}
            >
              {/* Image Frame */}
              <div className="relative aspect-4/3 w-full overflow-hidden bg-slate-950">
                <img 
                  src={currentImageUrl}
                  alt={slide.imageAlt || slide.headlineMain}
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  loading="eager"
                />

                {/* Subtle gradient overlay at bottom for text contrast */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent pointer-events-none" />

                {/* Bottom Caption Overlay */}
                <div className="absolute bottom-0 inset-x-0 p-4 sm:p-5">
                  <div className="bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-xl p-3 shadow-lg">
                    <p className="text-xs sm:text-sm font-semibold text-white line-clamp-1">
                      {slide.imageCaption || slide.headlineHighlight}
                    </p>
                  </div>
                </div>

              </div>

            </motion.div>
          </div>

        </div>

        {/* Bottom Interactive Controls & Slide Selector Strip */}
        <div className="pt-6 mt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Slide Navigation Buttons with Titles */}
          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
            {activeSlides.map((s, index) => {
              const isSelected = index === currentSlideIndex;
              return (
                <button
                  key={s.id}
                  onClick={() => setCurrentSlideIndex(index)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    isSelected 
                      ? 'bg-white text-slate-950 font-bold shadow-md' 
                      : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-slate-200 border border-white/5'
                  }`}
                >
                  <span className="font-mono text-[10px] opacity-70">0{index + 1}</span>
                  <span>{s.category}</span>
                </button>
              );
            })}
          </div>

          {/* Controls: Play/Pause, Prev, Next */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title={isPlaying ? 'Pause slideshow' : 'Play slideshow'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <button
              onClick={prevSlide}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Previous slide"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={nextSlide}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Next slide"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

export default HeroCarousel;
