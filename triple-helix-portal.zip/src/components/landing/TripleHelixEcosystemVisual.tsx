import React from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  ShieldCheck, 
  GraduationCap, 
  Briefcase
} from 'lucide-react';

export const TripleHelixEcosystemVisual: React.FC = () => {
  return (
    <div className="relative w-full aspect-[16/9] min-h-[520px] max-h-[720px] rounded-3xl overflow-hidden bg-[#F7FAFC] border border-slate-200/90 shadow-lg flex items-center justify-center p-4 sm:p-8 select-none">
      
      {/* 1. Subtle Engineering Blueprint Matrix Grid */}
      <div 
        className="absolute inset-0 opacity-40 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(16, 35, 63, 0.05) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(16, 35, 63, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '36px 36px'
        }}
      />

      {/* 2. Soft Ambient Vignettes with Luminous Neon Accents */}
      <div 
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-50"
        style={{ background: 'radial-gradient(circle, rgba(0, 195, 255, 0.18) 0%, rgba(23, 105, 170, 0.08) 50%, transparent 75%)' }}
      />
      <div 
        className="absolute bottom-1/4 left-1/3 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-50"
        style={{ background: 'radial-gradient(circle, rgba(0, 230, 118, 0.18) 0%, rgba(46, 139, 87, 0.08) 50%, transparent 75%)' }}
      />
      <div 
        className="absolute top-1/3 right-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-50"
        style={{ background: 'radial-gradient(circle, rgba(255, 214, 0, 0.22) 0%, rgba(212, 154, 36, 0.08) 50%, transparent 75%)' }}
      />

      {/* 3. SVG Layer for Flowing Connector Lines & Radiant Triple Helix Geometry */}
      <svg 
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
        viewBox="0 0 1200 675" 
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          {/* Gradients for Helix Loops */}
          <linearGradient id="govGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00C2FF" />
            <stop offset="60%" stopColor="#1769AA" />
            <stop offset="100%" stopColor="#2E8B57" />
          </linearGradient>

          <linearGradient id="acadGradient" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00E676" />
            <stop offset="60%" stopColor="#2E8B57" />
            <stop offset="100%" stopColor="#D49A24" />
          </linearGradient>

          <linearGradient id="indGradient" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFD600" />
            <stop offset="60%" stopColor="#D49A24" />
            <stop offset="100%" stopColor="#1769AA" />
          </linearGradient>

          {/* Luminous Neon Filter */}
          <filter id="neonPulse" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="5" result="blur1" />
            <feGaussianBlur stdDeviation="10" result="blur2" />
            <feMerge>
              <feMergeNode in="blur2" />
              <feMergeNode in="blur1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="subtleGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* --- Curved Connector Pathways between Entities & Helix (Sequenced after Helix) --- */}

        {/* Government Connector Lines */}
        <motion.path
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.7 }}
          transition={{ duration: 1.2, delay: 1.4, ease: 'easeInOut' }}
          d="M 310 180 C 440 180, 500 250, 540 280"
          fill="none"
          stroke="#00C2FF"
          strokeWidth="2.5"
          filter="url(#subtleGlow)"
        />
        <motion.path
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 1, delay: 1.6 }}
          d="M 310 220 C 420 220, 480 290, 530 310"
          fill="none"
          stroke="#1769AA"
          strokeWidth="1.5"
          strokeDasharray="4 6"
        />

        {/* Academia Connector Lines */}
        <motion.path
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.7 }}
          transition={{ duration: 1.2, delay: 1.6, ease: 'easeInOut' }}
          d="M 320 500 C 440 500, 500 420, 540 390"
          fill="none"
          stroke="#00E676"
          strokeWidth="2.5"
          filter="url(#subtleGlow)"
        />
        <motion.path
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 1, delay: 1.8 }}
          d="M 320 460 C 420 460, 480 380, 530 360"
          fill="none"
          stroke="#2E8B57"
          strokeWidth="1.5"
          strokeDasharray="4 6"
        />

        {/* Industry Connector Lines */}
        <motion.path
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.7 }}
          transition={{ duration: 1.2, delay: 1.8, ease: 'easeInOut' }}
          d="M 890 320 C 780 300, 720 320, 670 330"
          fill="none"
          stroke="#FFD600"
          strokeWidth="2.5"
          filter="url(#subtleGlow)"
        />
        <motion.path
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 1, delay: 2.0 }}
          d="M 890 360 C 780 380, 720 360, 670 350"
          fill="none"
          stroke="#D49A24"
          strokeWidth="1.5"
          strokeDasharray="4 6"
        />

        {/* --- Central Interconnected Triple Helix (Appears First, Stays Front & Center) --- */}
        <motion.g 
          transform="translate(600, 337.5)"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Subtle Outer Orbital Rings */}
          <circle r="175" fill="none" stroke="#CBD5E1" strokeWidth="1" strokeDasharray="4 6" opacity="0.6" />
          <circle r="140" fill="none" stroke="#E2E8F0" strokeWidth="1" />
          
          {/* Radiant Neon Halo behind Helix */}
          <circle r="115" fill="#FFFFFF" fillOpacity="0.8" filter="url(#subtleGlow)" />
          <circle r="95" fill="url(#govGradient)" fillOpacity="0.08" filter="url(#neonPulse)" />

          {/* Loop 1: Top Loop (Government - Neon Blue to Green) */}
          <path
            d="M 0 -25 C 45 -135, 125 -130, 95 -60 C 75 -10, 20 20, 0 35"
            fill="none"
            stroke="url(#govGradient)"
            strokeWidth="16"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#subtleGlow)"
          />

          {/* Loop 2: Bottom Left Loop (Academia - Neon Green to Gold) */}
          <path
            d="M -22 13 C -130 55, -135 130, -65 110 C -15 95, 15 35, 30 0"
            fill="none"
            stroke="url(#acadGradient)"
            strokeWidth="16"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#subtleGlow)"
          />

          {/* Loop 3: Bottom Right Loop (Industry - Neon Gold to Blue) */}
          <path
            d="M 22 13 C 130 55, 135 130, 65 110 C 15 95, -15 35, -30 0"
            fill="none"
            stroke="url(#indGradient)"
            strokeWidth="16"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#subtleGlow)"
          />

          {/* High-Luminance Neon Core Filaments */}
          <path
            d="M 0 -25 C 45 -135, 125 -130, 95 -60"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3.5"
            strokeLinecap="round"
            opacity="0.85"
          />
          <path
            d="M -22 13 C -130 55, -135 130, -65 110"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3.5"
            strokeLinecap="round"
            opacity="0.85"
          />
          <path
            d="M 22 13 C 130 55, 135 130, 65 110"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3.5"
            strokeLinecap="round"
            opacity="0.85"
          />

          {/* Neon Node Terminals */}
          <circle cx="85" cy="-80" r="5" fill="#00C2FF" filter="url(#subtleGlow)" />
          <circle cx="-85" cy="80" r="5" fill="#00E676" filter="url(#subtleGlow)" />
          <circle cx="85" cy="80" r="5" fill="#FFD600" filter="url(#subtleGlow)" />
        </motion.g>
      </svg>

      {/* 4. Interactive Content Layer: Central Emblem First, Then Entities Arrive */}
      <div className="relative w-full h-full max-w-[1140px] max-h-[640px] flex items-center justify-between z-20 pointer-events-auto">

        {/* --- LEFT COLUMN: Government (Top) & Academia (Bottom) (Arrives After Helix) --- */}
        <div className="w-[32%] h-full flex flex-col justify-between py-2 sm:py-4">
          
          {/* ENTITY 1: GOVERNMENT / COLLECTORATE (Arrives at delay: 1.5s) */}
          <motion.div
            initial={{ opacity: 0, x: -30, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.5, ease: 'easeOut' }}
            className="group relative bg-[#EAF4FC]/95 backdrop-blur-md border border-[#1769AA]/35 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-all max-w-[320px]"
          >
            {/* Header with Title & Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] sm:text-[11px] font-extrabold tracking-wider text-[#1769AA] uppercase font-mono">
                1. GOVERNMENT / COLLECTORATE
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#00C2FF] ring-4 ring-[#1769AA]/20 shadow-[0_0_8px_#00C2FF]" />
            </div>

            {/* Architectural Representation: Dignified Civic Collectorate Complex */}
            <div className="flex items-center gap-3 bg-white/90 border border-[#1769AA]/20 rounded-xl p-2.5 shadow-2xs mb-3">
              <div className="w-12 h-12 rounded-lg bg-[#EAF4FC] border border-[#1769AA]/30 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 40 40" className="w-8 h-8 text-[#1769AA]" fill="currentColor">
                  <path d="M 20 5 L 6 13 L 34 13 Z" fill="#1769AA" />
                  <rect x="18" y="2" width="4" height="4" rx="1" fill="#00C2FF" />
                  <line x1="20" y1="1" x2="20" y2="3" stroke="#D49A24" strokeWidth="1.5" />
                  <rect x="8" y="14" width="3" height="15" rx="0.5" fill="#1769AA" opacity="0.85" />
                  <rect x="14" y="14" width="3" height="15" rx="0.5" fill="#1769AA" opacity="0.85" />
                  <rect x="23" y="14" width="3" height="15" rx="0.5" fill="#1769AA" opacity="0.85" />
                  <rect x="29" y="14" width="3" height="15" rx="0.5" fill="#1769AA" opacity="0.85" />
                  <path d="M 18 29 L 18 20 Q 20 18 22 20 L 22 29 Z" fill="#10233F" opacity="0.25" />
                  <rect x="4" y="29" width="32" height="4" rx="1" fill="#1769AA" />
                  <rect x="2" y="33" width="36" height="2" rx="0.5" fill="#00C2FF" opacity="0.6" />
                </svg>
              </div>

              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-bold text-[#10233F] truncate">
                  District Collectorate
                </div>
                <div className="text-[11px] text-slate-500 font-medium truncate">
                  Civic Governance & Collector Gate
                </div>
              </div>
            </div>

            {/* Connection Representations */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center gap-2 text-[11px] text-[#10233F] font-semibold bg-white/85 px-2.5 py-1 rounded-md border border-[#1769AA]/20">
                <ShieldCheck className="w-3.5 h-3.5 text-[#1769AA] shrink-0" />
                <span>Policies & Institutional Support</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-[#10233F] font-semibold bg-white/85 px-2.5 py-1 rounded-md border border-[#1769AA]/20">
                <FileText className="w-3.5 h-3.5 text-[#1769AA] shrink-0" />
                <span>Verified Problem Statements</span>
              </div>
            </div>
          </motion.div>

          {/* ENTITY 2: ACADEMIA / INSTITUTIONS (Arrives at delay: 1.8s) */}
          <motion.div
            initial={{ opacity: 0, x: -30, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.8, ease: 'easeOut' }}
            className="group relative bg-[#EAF6EF]/95 backdrop-blur-md border border-[#2E8B57]/35 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-all max-w-[320px]"
          >
            {/* Header with Title & Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] sm:text-[11px] font-extrabold tracking-wider text-[#2E8B57] uppercase font-mono">
                2. ACADEMIA / INSTITUTIONS
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#00E676] ring-4 ring-[#2E8B57]/20 shadow-[0_0_8px_#00E676]" />
            </div>

            {/* Architectural Representation: Modern Engineering University Campus */}
            <div className="flex items-center gap-3 bg-white/90 border border-[#2E8B57]/20 rounded-xl p-2.5 shadow-2xs mb-3">
              <div className="w-12 h-12 rounded-lg bg-[#EAF6EF] border border-[#2E8B57]/30 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 40 40" className="w-8 h-8 text-[#2E8B57]" fill="currentColor">
                  <rect x="6" y="16" width="14" height="17" rx="1" fill="#2E8B57" />
                  <rect x="22" y="10" width="12" height="23" rx="1" fill="#2E8B57" opacity="0.85" />
                  <rect x="8" y="19" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="13" y="19" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="8" y="24" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="13" y="24" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="24" y="13" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="29" y="13" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="24" y="18" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="29" y="18" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="24" y="23" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <rect x="29" y="23" width="3" height="3" fill="#FFFFFF" opacity="0.75" />
                  <polygon points="4,16 20,16 18,13 6,13" fill="#00E676" opacity="0.85" />
                  <rect x="3" y="33" width="34" height="2" rx="0.5" fill="#00E676" opacity="0.6" />
                </svg>
              </div>

              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-bold text-[#10233F] truncate">
                  Engineering Colleges
                </div>
                <div className="text-[11px] text-slate-500 font-medium truncate">
                  Accredited Labs & Student Faculty
                </div>
              </div>
            </div>

            {/* Connection Representation */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center gap-2 text-[11px] text-[#10233F] font-semibold bg-white/85 px-2.5 py-1.5 rounded-md border border-[#2E8B57]/20">
                <GraduationCap className="w-3.5 h-3.5 text-[#2E8B57] shrink-0" />
                <span>Student Talent & Hardware Engineering</span>
              </div>
            </div>
          </motion.div>

        </div>

        {/* --- CENTER: Main Focus Triple Helix Emblem (Occupies 45-50% Visual Attention) --- */}
        <div className="w-[36%] flex items-center justify-center">
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex flex-col items-center justify-center text-center p-6 sm:p-7 rounded-3xl bg-white/95 backdrop-blur-xl border border-slate-200/90 shadow-2xl max-w-[280px] sm:max-w-[310px]"
            style={{
              boxShadow: '0 20px 45px -12px rgba(16, 35, 63, 0.15), 0 0 25px rgba(0, 195, 255, 0.1)'
            }}
          >
            {/* Core Triple Helix Intersecting Indicator */}
            <div className="flex items-center justify-center gap-2 mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00C2FF] shadow-[0_0_6px_#00C2FF]" title="Government" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#00E676] shadow-[0_0_6px_#00E676]" title="Academia" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFD600] shadow-[0_0_6px_#FFD600]" title="Industry" />
            </div>

            {/* MANDATORY CENTER PHRASE: "COLLABORATION FOR REAL-WORLD IMPACT" */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">
                Tripartite Synthesis
              </span>
              <h3 className="text-sm sm:text-base font-extrabold text-[#10233F] tracking-tight leading-snug uppercase">
                “COLLABORATION FOR REAL-WORLD IMPACT”
              </h3>
            </div>

            <div className="w-14 h-1 bg-gradient-to-r from-[#00C2FF] via-[#00E676] to-[#FFD600] rounded-full my-3 shadow-xs" />

            <p className="text-[11px] text-slate-600 leading-relaxed font-normal">
              A synchronized innovation engine converting civic challenges into deployed, field-tested engineering solutions.
            </p>
          </motion.div>
        </div>

        {/* --- RIGHT COLUMN: Industry / Mentors (Arrives at delay: 2.1s) --- */}
        <div className="w-[32%] h-full flex flex-col justify-center py-2 sm:py-4">
          
          {/* ENTITY 3: INDUSTRY / MENTORS (Generalized, No Specific Company Names) */}
          <motion.div
            initial={{ opacity: 0, x: 30, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 2.1, ease: 'easeOut' }}
            className="group relative bg-[#FFF5DD]/95 backdrop-blur-md border border-[#D49A24]/35 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-all max-w-[320px] ml-auto"
          >
            {/* Header with Title & Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] sm:text-[11px] font-extrabold tracking-wider text-[#D49A24] uppercase font-mono">
                3. INDUSTRY / MENTORS
              </span>
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFD600] ring-4 ring-[#D49A24]/20 shadow-[0_0_8px_#FFD600]" />
            </div>

            {/* Architectural Representation: Modern Technology & Engineering Corporate Headquarters */}
            <div className="flex items-center gap-3 bg-white/90 border border-[#D49A24]/20 rounded-xl p-2.5 shadow-2xs mb-3">
              <div className="w-12 h-12 rounded-lg bg-[#FFF5DD] border border-[#D49A24]/30 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 40 40" className="w-8 h-8 text-[#D49A24]" fill="currentColor">
                  <path d="M 8 12 L 20 8 L 32 12 L 32 33 L 8 33 Z" fill="#D49A24" />
                  <rect x="11" y="14" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="21" y="14" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="11" y="20" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="21" y="20" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="11" y="26" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="21" y="26" width="8" height="4" rx="0.5" fill="#FFFFFF" opacity="0.75" />
                  <rect x="17" y="27" width="6" height="6" rx="0.5" fill="#10233F" opacity="0.3" />
                  <line x1="20" y1="8" x2="20" y2="3" stroke="#FFD600" strokeWidth="1.5" />
                  <circle cx="20" cy="3" r="1.5" fill="#00C2FF" />
                  <rect x="5" y="33" width="30" height="2" rx="0.5" fill="#FFD600" opacity="0.6" />
                </svg>
              </div>

              {/* Generalized Title & Description (No specific company names) */}
              <div className="min-w-0">
                <div className="text-xs sm:text-sm font-bold text-[#10233F] truncate">
                  Technology Enterprises
                </div>
                <div className="text-[11px] text-slate-500 font-medium truncate">
                  Corporate & Technical Domain Mentors
                </div>
              </div>
            </div>

            {/* Connection Representation */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center gap-2 text-[11px] text-[#10233F] font-semibold bg-white/85 px-2.5 py-1.5 rounded-md border border-[#D49A24]/20">
                <Briefcase className="w-3.5 h-3.5 text-[#D49A24] shrink-0" />
                <span>Industry Mentorship & Deployed Solutions</span>
              </div>
            </div>
          </motion.div>

        </div>

      </div>

    </div>
  );
};

export default TripleHelixEcosystemVisual;
